---
layout: page
title: "ABOUT"
description: "Hey, i'm JackSunny"
header-img: "img/about-bg.jpg"

---

*写写代码，看看书，虽不能喂马劈柴，但想周游世界，每一个程序员都有一颗闷骚的心，沉重的雾霾里却想去飞翔，好湿*

qq: 395947643